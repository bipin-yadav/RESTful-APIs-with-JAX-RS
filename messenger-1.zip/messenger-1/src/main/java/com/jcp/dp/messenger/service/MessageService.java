package com.jcp.dp.messenger.service;

import java.util.List;

import com.jcp.dp.messenger.model.Message;

public interface MessageService {
	
	public List<Message> getAllMessages();
	public Message getMessage(long id);
	public Message addMessage(Message message);
	public Message updateMessage(Message message);
	public Message removeMessage(long id);
	public List<Message> getAllMessagesByYear(int year);
	public List<Message> getAllMessagesPaginated(int start, int size);
}
