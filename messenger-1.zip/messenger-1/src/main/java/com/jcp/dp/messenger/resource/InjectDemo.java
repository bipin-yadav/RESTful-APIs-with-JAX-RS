package com.jcp.dp.messenger.resource;

import javax.ws.rs.CookieParam;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.MatrixParam;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.UriInfo;


@Path("/inject")
public class InjectDemo {
	
	@GET
	@Path("/annotations")
	@Produces(MediaType.TEXT_PLAIN)
	public String getParamByAnnotations(@MatrixParam("param") String param1,
							  @CookieParam("JSESSIONID") String param3,
							  @HeaderParam("cutomHeaderValue") String param2){
		return "Test- param is: "+param1+" header value : " + param2+" cookie "+ param3;
	}
	
	@GET
	@Path("/context")
	@Produces(MediaType.TEXT_PLAIN)
	public String getParamByContext(@Context UriInfo uriInfo, 
									@Context HttpHeaders httpHeader){
		String path = uriInfo.getAbsolutePath().toString();
		String cookies = httpHeader.getCookies().toString();
		return "Path: " + path+" cookies: "+ cookies;
		
	}

}
