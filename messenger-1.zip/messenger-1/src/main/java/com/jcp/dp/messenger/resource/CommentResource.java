package com.jcp.dp.messenger.resource;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;

@Path("/")
public class CommentResource {
	
	@GET
	public String getMessageComments(){
		return "new sub resource";
	}
	
	@GET
	@Path("/{commentId}")
	public String getMessageCommentsById(@PathParam("messageId") long mid, 
									     @PathParam("commentId") long cid){
		return "new sub resource " + mid +" commentid "+cid;
	}
	
}
