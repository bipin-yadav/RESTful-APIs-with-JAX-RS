package com.jcp.dp.messenger.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import com.jcp.dp.messenger.database.DatabaseClass;
import com.jcp.dp.messenger.model.Profile;
import com.jcp.dp.messenger.service.ProfileService;

public class ProfileServiceImpl implements ProfileService{
	
	private Map<String, Profile> profiles = DatabaseClass.getProfiles();
	
	public ProfileServiceImpl() {
		 profiles.put("bipin", new Profile(1L,"bipin","bipin","yadav", new Date()));
	}

	@Override
	public List<Profile> getAllProfiles() {
		return new ArrayList<Profile>(profiles.values());
	}

	@Override
	public Profile getProfile(String id) {
		return profiles.get(id);
	}

	@Override
	public Profile addProfile(Profile profile) {
		profile.setId(profiles.size() + 1);
		profiles.put(profile.getProfileName(), profile);
		return profile;
	}

	@Override
	public Profile updateProfile(Profile profile) {
		if(profile.getId() <= 0){
			return null;
		}
		profiles.put(profile.getProfileName(), profile);
		return profile;
	}

	@Override
	public Profile removeProfile(String id) {
		return profiles.remove(id);
	}

}
