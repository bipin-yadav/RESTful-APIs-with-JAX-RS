package com.jcp.dp.messenger.service;

import java.util.List;

import com.jcp.dp.messenger.model.Profile;

public interface ProfileService {
	
	public List<Profile> getAllProfiles();
	public Profile getProfile(String id);
	public Profile addProfile(Profile message);
	public Profile updateProfile(Profile message);
	public Profile removeProfile(String id);

}
