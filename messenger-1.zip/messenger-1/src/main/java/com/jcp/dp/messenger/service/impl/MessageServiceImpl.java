package com.jcp.dp.messenger.service.impl;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;

import com.jcp.dp.messenger.database.DatabaseClass;
import com.jcp.dp.messenger.model.Message;
import com.jcp.dp.messenger.service.MessageService;

public class MessageServiceImpl implements MessageService{
	
	public Map<Long, Message> messages = DatabaseClass.getMessages();
	
	public MessageServiceImpl(){
		messages.put(1L, new Message(1l,"bipin", new Date(), "bipin"));
		messages.put(2L, new Message(2l,"yadav", new Date(), "yadav"));
	}
	
	@Override
	public List<Message> getAllMessages(){
		return new ArrayList<Message>(messages.values());
	}

	@Override
	public Message getMessage(long id) {
		return messages.get(id);
	}

	@Override
	public Message addMessage(Message message) {
		message.setId(messages.size() + 1);
		messages.put(message.getId(), message);
		return message;
	}

	@Override
	public Message updateMessage(Message message) {
		if(message.getId() <= 0){
			return null;
		}
		messages.put(message.getId(), message);
		return message;
	}

	@Override
	public Message removeMessage(long id) {
		return messages.remove(id);
	}

	@Override
	public List<Message> getAllMessagesByYear(int year) {
		List<Message> list = new ArrayList<>();
		Calendar calender = Calendar.getInstance();
		for(Message message : messages.values()){
			calender.setTime(message.getCreated());
			if(calender.get(Calendar.YEAR) == year){
				list.add(message);
			}
		}
		return list;
	}

	@Override
	public List<Message> getAllMessagesPaginated(int start, int size) {		
		return new ArrayList<Message>(messages.values()).subList(start, start+size);
	}

	 

}
