package com.jcp.dp.messenger.resource;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.jcp.dp.messenger.model.Profile;
import com.jcp.dp.messenger.service.ProfileService;
import com.jcp.dp.messenger.service.impl.ProfileServiceImpl;

@Path("/profiles")
public class ProfileResource {
	
	ProfileService profileservice = new ProfileServiceImpl();
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	//@Produces(MediaType.APPLICATION_XML)
	public List<Profile> getMessages(){
		return profileservice.getAllProfiles();
	}
	
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public Profile addMessage(Profile message){
		return profileservice.addProfile(message);
	}
	
	@PUT
	@Path("/{profileId}")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public Profile update(@PathParam("profileId") String id, Profile message){
		message.setProfileName(id);
		return profileservice.updateProfile(message);
	}
	
	@DELETE
	@Path("/{profileId}")
	@Produces(MediaType.APPLICATION_JSON)
	public void delMessage(@PathParam("profileId") String id){
		profileservice.removeProfile(id);
	}
	
	@GET
	@Path("/{profileId}")
	//@Produces(MediaType.APPLICATION_XML)
	@Produces(MediaType.APPLICATION_JSON)
	public Profile getMessage(@PathParam("profileId") String id){
		return profileservice.getProfile(id);
	}

}
