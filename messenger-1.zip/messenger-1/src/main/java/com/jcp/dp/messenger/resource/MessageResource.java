package com.jcp.dp.messenger.resource;

import java.util.List;

import javax.ws.rs.BeanParam;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import com.jcp.dp.messenger.model.Message;
import com.jcp.dp.messenger.service.MessageService;
import com.jcp.dp.messenger.service.impl.MessageServiceImpl;

@Path("/messages")
public class MessageResource {
	
	MessageService messageService = new MessageServiceImpl();
	
	@Path("/beanParam")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<Message> getMessagesByBeanParam(@BeanParam MessageFilterBean messageFiletrBean){
		if(messageFiletrBean.getYear() > 0){
			return messageService.getAllMessagesByYear(messageFiletrBean.getYear());
		}
		if(messageFiletrBean.getSize() >= 0 && messageFiletrBean.getStart() >= 0){
			return messageService.getAllMessagesPaginated(messageFiletrBean.getStart(), 
					messageFiletrBean.getSize());
		}
		return messageService.getAllMessages();
	}
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	//@Produces(MediaType.APPLICATION_XML)
	public List<Message> getMessages(@QueryParam("year") int year,
								     @QueryParam("start") int start,
								     @QueryParam("size") int size ){
		if(year > 0){
			return messageService.getAllMessagesByYear(year);
		}
		if(start >= 0 && size >= 0){
			return messageService.getAllMessagesPaginated(start, size);
		}
		return messageService.getAllMessages();
	}
		
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public Message addMessage(Message message){
		return messageService.addMessage(message);
	}
	
	@PUT
	@Path("/{messageId}")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public Message update(@PathParam("messageId") long id, Message message){
		message.setId(id);
		return messageService.updateMessage(message);
	}
	
	@DELETE
	@Path("/{messageId}")
	@Produces(MediaType.APPLICATION_JSON)
	public void delMessage(@PathParam("messageId") long id){
		messageService.removeMessage(id);
	}
	
	@GET
	@Path("/{messageId}")
	//@Produces(MediaType.APPLICATION_XML)
	@Produces(MediaType.APPLICATION_JSON)
	public Message getMessage(@PathParam("messageId") long id){
		return messageService.getMessage(id);
	}
	
	@Path("/{messageId}/comments")
	@Produces(MediaType.APPLICATION_JSON)
	public CommentResource getMessageComments(){
		return new CommentResource();
	}
	
}
